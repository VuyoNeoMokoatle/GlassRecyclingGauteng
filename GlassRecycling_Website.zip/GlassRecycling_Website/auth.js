// Register
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
    if (!email || !password) {
      alert("Please fill in all fields");
      return;
    }
    localStorage.setItem("user", JSON.stringify({ email, password }));
    alert("Account created successfully!");
    window.location.href = "login.html";
  });
}

// Login
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const user = JSON.parse(localStorage.getItem("user"));

    if (user && user.email === email && user.password === password) {
      localStorage.setItem("loggedIn", "true");
      alert("Login successful!");
      window.location.href = "shop.html"; // Redirect to shop after login
    } else {
      alert("Invalid email or password");
    }
  });
}
// auth.js

function login(username, password) {
  // Example credentials
  if (username === "admin" && password === "admin123") {
    localStorage.setItem("loggedIn", "admin");
    window.location.href = "admin.html";
    return;
  }
  if (username === "user" && password === "user123") {
    localStorage.setItem("loggedIn", "user");
    window.location.href = "index.html";
    return;
  }
  alert("Invalid credentials");
}

// Access Restriction
if (window.location.pathname.includes("shop.html") ||
    window.location.pathname.includes("cart.html") ||
    window.location.pathname.includes("checkout.html")) {
  const isLoggedIn = localStorage.getItem("loggedIn");
  if (!isLoggedIn) {
    alert("Please login to access this page");
    window.location.href = "login.html";
  }
}

// Logout function (add this to navbar later)
function logout() {
  localStorage.removeItem("loggedIn");
  alert("You have logged out");
  window.location.href = "login.html";
}
