// ===== CART LOGIC =====
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Add product to cart with quantity (require login)
function addToCart(name, price, quantity) {
  const loggedIn = localStorage.getItem("loggedIn");
  const username = localStorage.getItem("username");

  if (!loggedIn) {
    alert("❌ You must be logged in to add products to your cart.");
    window.location.href = "login.html";
    return;
  }

  quantity = parseInt(quantity);
  if (quantity < 1) quantity = 1;

  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ name, price, quantity });
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  displayCart();
  alert(`✅ ${username}, ${name} x${quantity} added to your cart!`);
}

// Display cart items on cart page
function displayCart() {
  const cartItemsDiv = document.getElementById("cartItems");
  if (!cartItemsDiv) return;

  if (cart.length === 0) {
    cartItemsDiv.innerHTML = `<p class="text-center text-gray-600 text-lg">🛒 Your cart is empty.</p>`;
    updateTotal();
    return;
  }

  cartItemsDiv.innerHTML = cart
    .map((item, i) => `
      <div class="bg-white border p-4 flex justify-between items-center rounded mb-2">
        <p>${item.name} x ${item.quantity}</p>
        <p>R${item.price * item.quantity}</p>
        <button onclick="removeItem(${i})" class="bg-red-500 text-white px-2 py-1 rounded">Remove</button>
      </div>
    `).join("");

  updateTotal();
}

// Update total price
function updateTotal() {
  const totalPriceSpan = document.getElementById("totalPrice");
  if (!totalPriceSpan) return;

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  totalPriceSpan.textContent = `R ${total}`;
}

// Remove single item from cart
function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  displayCart();
}

// Clear entire cart
function clearCart() {
  if (cart.length === 0) {
    alert("Your cart is already empty!");
    return;
  }
  if (confirm("Do you want to clear the entire cart?")) {
    cart = [];
    localStorage.removeItem("cart");
    displayCart();
  }
}

// Proceed to checkout (requires items)
function proceedToCheckout() {
  if (cart.length === 0) {
    alert("🛒 Your cart is empty! Please add products before proceeding to checkout.");
    return;
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  window.location.href = "checkout.html";
}

// ===== CHECKOUT =====
function validateCheckout() {
  if (cart.length === 0) {
    alert("Your cart is empty! Add some products before checking out.");
    return;
  }

  // Get form inputs
  const fullName = document.querySelector("#checkoutForm input[type='text']").value.trim();
  const email = document.querySelector("#checkoutForm input[type='email']").value.trim();
  const address = document.querySelector("#checkoutForm textarea").value.trim();

  // Validate inputs
  if (!fullName || !email || !address) {
    alert("Please fill in all required details: Full Name, Email, and Delivery Address.");
    return;
  }

  // Optional: Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  // All good, place the order
  placeOrder();
}

function placeOrder() {
  const orderNumber = "GRG" + Math.floor(Math.random() * 1000).toString().padStart(3, "0");
  const username = localStorage.getItem("username");
  alert(`✅ Thank you ${username}! Your order has been placed.\nOrder Number: ${orderNumber}`);
  cart = [];
  localStorage.removeItem("cart");
  displayCart();
  displayCheckoutCart();
}

// ===== ORDER TRACKING =====
const orders = [
  { orderNumber: "GRG001", status: "Processing" },
  { orderNumber: "GRG002", status: "Shipped" },
  { orderNumber: "GRG003", status: "Out for Delivery" },
  { orderNumber: "GRG004", status: "Delivered" }
];

function trackOrder() {
  const input = document.getElementById("orderInput");
  const statusDiv = document.getElementById("orderStatus");
  if (!input || !statusDiv) return;

  const search = input.value.trim().toUpperCase();
  const result = orders.find(order => order.orderNumber === search);

  if (result) {
    statusDiv.innerHTML = `
      <div class="bg-green-100 border border-green-300 p-3 rounded text-green-900 font-medium">
        ✅ Order <strong>${result.orderNumber}</strong> is currently: <strong>${result.status}</strong>
      </div>`;
  } else {
    statusDiv.innerHTML = `
      <div class="bg-red-100 border border-red-300 p-3 rounded text-red-800 font-medium">
        ❌ Order not found. Please check your order number.
      </div>`;
  }
}

// ===== GOOGLE MAPS =====
function initMap() {
  const gauteng = { lat: -26.2041, lng: 28.0473 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 9,
    center: gauteng
  });

  // Demo drop-off pins
  const locations = [
    { position: { lat: -26.256, lng: 27.854 }, title: "Soweto Branch" },
    { position: { lat: -26.194, lng: 28.033 }, title: "Braamfontein Branch" },
    { position: { lat: -26.204, lng: 28.047 }, title: "Johannesburg Central Branch" }
  ];

  locations.forEach(loc => new google.maps.Marker({
    position: loc.position,
    map: map,
    title: loc.title
  }));
}

// ===== LOGIN & USER NAVBAR =====
const users = [
  { username: "admin", password: "admin123", role: "admin" },
  { username: "user", password: "user123", role: "user" }
];

function login(username, password) {
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) {
    alert("Invalid username or password");
    return false;
  }
  localStorage.setItem("loggedIn", user.role);
  localStorage.setItem("username", user.username);
  alert(`Welcome, ${user.username}!`);
  updateNavbar();
  return true;
}

function register(username, password) {
  if (users.find(u => u.username === username)) {
    alert("Username already exists");
    return false;
  }
  users.push({ username, password, role: "user" });
  alert("Registration successful! Please login.");
  return true;
}

function updateNavbar() {
  const loggedIn = localStorage.getItem("loggedIn");
  const username = localStorage.getItem("username");

  const adminBtn = document.getElementById("adminBtn");
  const mobileAdminBtn = document.getElementById("mobileAdminBtn");
  const loginLink = document.getElementById("loginLink");
  const mobileLoginLink = document.getElementById("mobileLoginLink");

  if (loggedIn === "admin") {
    adminBtn?.classList.remove("hidden");
    mobileAdminBtn?.classList.remove("hidden");
    loginLink?.classList.add("hidden");
    mobileLoginLink?.classList.add("hidden");
  } else if (loggedIn === "user") {
    loginLink.textContent = `Hi, ${username}`;
    loginLink.href = "index.html";
    mobileLoginLink.textContent = `Hi, ${username}`;
    mobileLoginLink.href = "index.html";
  } else {
    loginLink.textContent = "Login";
    loginLink.href = "login.html";
    mobileLoginLink.textContent = "Login";
    mobileLoginLink.href = "login.html";
    adminBtn?.classList.add("hidden");
    mobileAdminBtn?.classList.add("hidden");
  }
}

function logout() {
  localStorage.removeItem("loggedIn");
  localStorage.removeItem("username");
  updateNavbar();
}

// ===== INITIALIZE ON PAGE LOAD =====
window.addEventListener("load", () => {
  cart = JSON.parse(localStorage.getItem("cart")) || [];
  displayCart();
  displayCheckoutCart();
  updateNavbar();
  if (document.getElementById("map")) initMap();
});
