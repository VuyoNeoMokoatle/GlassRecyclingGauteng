/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.html"  // All HTML files in your project folder
  ],
  theme: {
    extend: {
      colors: {
        primaryGreen: '#16a34a', // Example custom green
        secondaryGreen: '#22c55e',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
    },
  },
  plugins: [],
}
