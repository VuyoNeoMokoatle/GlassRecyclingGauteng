// Ensure only admin can access
if (localStorage.getItem("loggedIn") !== "admin") {
  alert("Access Denied! Admins only.");
  window.location.href = "login.html";
}

// Example orders stored in localStorage
let orders = JSON.parse(localStorage.getItem("orders")) || [
  { orderNumber: "GRG001", customer: "Neo", status: "Processing" },
  { orderNumber: "GRG002", customer: "Keabetswe", status: "Shipped" },
];

function displayOrders() {
  const ordersDiv = document.getElementById("ordersList");
  ordersDiv.innerHTML = orders
    .map(
      (order, i) => `
      <div class="flex justify-between items-center border-b pb-2">
        <p><strong>${order.orderNumber}</strong> | ${order.customer} | ${order.status}</p>
        <select onchange="updateStatus(${i}, this.value)" class="border rounded p-1">
          <option ${order.status === "Processing" ? "selected" : ""}>Processing</option>
          <option ${order.status === "Shipped" ? "selected" : ""}>Shipped</option>
          <option ${order.status === "Out for Delivery" ? "selected" : ""}>Out for Delivery</option>
          <option ${order.status === "Delivered" ? "selected" : ""}>Delivered</option>
        </select>
      </div>`
    )
    .join("");
}

function updateStatus(index, status) {
  orders[index].status = status;
  localStorage.setItem("orders", JSON.stringify(orders));
  displayOrders();
}

// Initialize display
displayOrders();
